import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-secondary mb-4">About Me</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </motion.div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            className="order-2 lg:order-1"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Professional developer workspace with multiple monitors showing code" 
              className="rounded-xl shadow-xl w-full h-auto"
            />
          </motion.div>
          
          <motion.div 
            className="order-1 lg:order-2"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-secondary mb-6">Passionate Full-Stack Developer</h3>
            <p className="text-muted-foreground mb-6 text-lg leading-relaxed">
              I'm a B.E. Computer Science graduate from Chandigarh University with hands-on experience in backend systems, distributed architecture, and scalable API design. My expertise spans across multiple technologies including Java, Python, and modern web frameworks.
            </p>
            <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
              With a strong foundation in cloud technologies, DevOps practices, and agile methodologies, I'm passionate about creating efficient, scalable solutions that solve real-world problems.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-semibold text-secondary mb-2">Education</h4>
                  <p className="text-muted-foreground">B.E. Computer Science</p>
                  <p className="text-sm text-muted-foreground">CGPA: 7.54/10</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-semibold text-secondary mb-2">Location</h4>
                  <p className="text-muted-foreground">Bengaluru, Karnataka</p>
                  <p className="text-sm text-muted-foreground">Open to Remote</p>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
