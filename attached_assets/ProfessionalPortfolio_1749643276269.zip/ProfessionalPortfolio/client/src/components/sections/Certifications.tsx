import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Star, Trophy, Briefcase } from "lucide-react";

export default function Certifications() {
  const certifications = [
    {
      title: "AWS Cloud Solutions Architect",
      issuer: "Coursera",
      year: "2024",
      description: "Comprehensive program covering cloud architecture, infrastructure deployment, and AWS services.",
      icon: "🏆",
      verified: true
    },
    {
      title: "Computer Vision Specialization",
      issuer: "Coursera",
      year: "2023",
      description: "Machine learning, object tracking, and motion detection using MATLAB and computer vision techniques.",
      icon: "👁️",
      verified: true
    },
    {
      title: "Machine Learning Training",
      issuer: "Internshala",
      year: "2022",
      description: "6-week intensive training covering ML algorithms, data preprocessing, and model evaluation. Top performer with 100% score.",
      icon: "🤖",
      topPerformer: true
    },
    {
      title: "Azure Fundamentals",
      issuer: "Microsoft",
      year: "2024",
      description: "Cloud skill challenge focusing on Azure fundamentals and cloud computing concepts.",
      icon: "☁️",
      verified: true
    },
    {
      title: "AMCAT Assessment",
      issuer: "Aspiring Minds",
      year: "2023",
      description: "High-scoring candidate in multiple technical domains including programming, computer science, and logical reasoning.",
      icon: "📊",
      highPerformer: true
    },
    {
      title: "IoT & Embedded Systems",
      issuer: "Training Program",
      year: "2021",
      description: "Comprehensive training in IoT, Robotics, and Embedded Systems development and implementation.",
      icon: "🔧",
      verified: true
    }
  ];

  const achievements = [
    {
      title: "HackerRank Java",
      description: "5-Star Rating in Java Programming (2024)",
      icon: <Star className="h-6 w-6 text-yellow-600" />
    },
    {
      title: "Google Cloud Program",
      description: "100% badges in Cloud Ready Facilitator Program",
      icon: <Award className="h-6 w-6 text-green-600" />
    },
    {
      title: "JP Morgan Virtual Internship",
      description: "Software Engineering Program with financial data analysis",
      icon: <Briefcase className="h-6 w-6 text-blue-600" />
    }
  ];

  return (
    <section id="certifications" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-secondary mb-4">Certifications & Achievements</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-muted-foreground text-lg">Professional certifications and learning achievements</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mr-4 text-2xl">
                      {cert.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-secondary">{cert.title}</h3>
                      <p className="text-sm text-muted-foreground">{cert.issuer} • {cert.year}</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm mb-4">{cert.description}</p>
                  <div className="flex items-center text-sm">
                    {cert.verified && (
                      <Badge variant="secondary" className="text-primary">
                        <Award className="h-3 w-3 mr-1" />
                        Verified Certificate
                      </Badge>
                    )}
                    {cert.topPerformer && (
                      <Badge variant="secondary" className="text-green-600">
                        <Trophy className="h-3 w-3 mr-1" />
                        Top Performer
                      </Badge>
                    )}
                    {cert.highPerformer && (
                      <Badge variant="secondary" className="text-primary">
                        <Star className="h-3 w-3 mr-1" />
                        High Performer
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Achievements Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <Card className="shadow-lg">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-secondary mb-6 text-center">Notable Achievements</h3>
              <div className="grid md:grid-cols-3 gap-6">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.title}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      {achievement.icon}
                    </div>
                    <h4 className="font-semibold text-secondary mb-2">{achievement.title}</h4>
                    <p className="text-muted-foreground text-sm">{achievement.description}</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
