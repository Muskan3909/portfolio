import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";

export default function Projects() {
  const projects = [
    {
      title: "TaskTrackerPro",
      description: "Full-stack task management application built with Angular 19 and Python Flask. Features CRUD operations, real-time updates, and responsive design.",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      technologies: ["Angular", "Flask", "PostgreSQL", "Bootstrap"],
      githubUrl: "https://github.com/Muskan3909/TaskTrackerPro",
      liveUrl: "https://tasktrackerpro-backend.onrender.com/",
      isLatest: true
    },
    {
      title: "COVID-19 Predictor",
      description: "AI-based predictive model for COVID-19 identification using machine learning techniques including Random Forests, SVMs, and Neural Networks.",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      technologies: ["Python", "Flask", "OpenCV", "ML/AI"],
      githubUrl: null,
      liveUrl: null,
      isLatest: false
    },
    {
      title: "Book Review API",
      description: "RESTful API for managing book reviews with user authentication, secure routing, and CRUD operations built with Node.js and Express.js.",
      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      technologies: ["Node.js", "Express.js", "MongoDB", "JWT"],
      githubUrl: "#",
      liveUrl: null,
      isLatest: false
    },
    {
      title: "Hospital Management System",
      description: "Comprehensive web-based system for managing patient records, doctor assignments, and hospital administration with remote access capabilities.",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      technologies: ["HTML/CSS", "JavaScript", "PHP", "MySQL"],
      githubUrl: "#",
      liveUrl: null,
      isLatest: false
    }
  ];

  const getTechColor = (tech: string) => {
    const colors: { [key: string]: string } = {
      "Angular": "bg-red-100 text-red-800",
      "Flask": "bg-green-100 text-green-800",
      "PostgreSQL": "bg-blue-100 text-blue-800",
      "Bootstrap": "bg-purple-100 text-purple-800",
      "Python": "bg-yellow-100 text-yellow-800",
      "OpenCV": "bg-indigo-100 text-indigo-800",
      "ML/AI": "bg-pink-100 text-pink-800",
      "Node.js": "bg-green-100 text-green-800",
      "Express.js": "bg-gray-100 text-gray-800",
      "MongoDB": "bg-green-100 text-green-800",
      "JWT": "bg-blue-100 text-blue-800",
      "HTML/CSS": "bg-orange-100 text-orange-800",
      "JavaScript": "bg-yellow-100 text-yellow-800",
      "PHP": "bg-purple-100 text-purple-800",
      "MySQL": "bg-blue-100 text-blue-800"
    };
    return colors[tech] || "bg-gray-100 text-gray-800";
  };

  return (
    <section id="projects" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-secondary mb-4">Featured Projects</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-muted-foreground text-lg">Showcasing my latest work and technical expertise</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative">
                  <img 
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover"
                  />
                  {project.isLatest && (
                    <Badge className="absolute top-4 right-4 bg-primary text-primary-foreground">
                      Latest
                    </Badge>
                  )}
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold text-secondary mb-4">{project.title}</h3>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech) => (
                      <Badge key={tech} variant="secondary" className={getTechColor(tech)}>
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex space-x-4">
                    {project.githubUrl && (
                      <Button asChild className="flex-1">
                        <a 
                          href={project.githubUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className={project.githubUrl === "#" ? "opacity-50 pointer-events-none" : ""}
                        >
                          <Github className="h-4 w-4 mr-2" />
                          {project.githubUrl === "#" ? "Private Repo" : "GitHub"}
                        </a>
                      </Button>
                    )}
                    {project.liveUrl && (
                      <Button asChild variant="outline" className="flex-1">
                        <a 
                          href={project.liveUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Live Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
