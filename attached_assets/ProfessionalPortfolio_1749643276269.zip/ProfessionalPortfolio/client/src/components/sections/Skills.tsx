import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Code, Layers, Database, Wrench, CheckCircle } from "lucide-react";

export default function Skills() {
  const skillCategories = [
    {
      title: "Programming",
      icon: <Code className="h-8 w-8" />,
      color: "text-primary",
      skills: [
        { name: "Java", level: 90 },
        { name: "Python", level: 85 },
        { name: "JavaScript", level: 80 },
      ]
    },
    {
      title: "Frameworks",
      icon: <Layers className="h-8 w-8" />,
      color: "text-accent",
      items: ["Spring Boot", "Express.js", "Flask", "ReactJS", "Angular", "REST APIs"]
    },
    {
      title: "Data & Cloud",
      icon: <Database className="h-8 w-8" />,
      color: "text-yellow-600",
      items: ["PostgreSQL", "MongoDB", "MySQL", "AWS", "GCP", "Docker"]
    },
    {
      title: "Tools & Methods",
      icon: <Wrench className="h-8 w-8" />,
      color: "text-purple-600",
      items: ["Git/GitHub", "Jenkins", "Maven", "Agile/Scrum", "TDD", "CI/CD"]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-secondary mb-4">Technical Skills</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-muted-foreground text-lg">Technologies and tools I work with</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`${category.color} mb-4`}>
                    {category.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-secondary mb-4">{category.title}</h3>
                  
                  {category.skills ? (
                    <div className="space-y-4">
                      {category.skills.map((skill) => (
                        <div key={skill.name}>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium">{skill.name}</span>
                            <span className="text-sm text-muted-foreground">{skill.level}%</span>
                          </div>
                          <Progress value={skill.level} className="h-2" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <ul className="space-y-2">
                      {category.items?.map((item) => (
                        <li key={item} className="flex items-center text-sm">
                          <CheckCircle className="h-4 w-4 text-green-600 mr-2 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
